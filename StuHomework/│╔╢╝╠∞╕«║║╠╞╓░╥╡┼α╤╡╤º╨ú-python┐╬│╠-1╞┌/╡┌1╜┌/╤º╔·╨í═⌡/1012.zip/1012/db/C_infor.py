import pickle
a=[]
f=open("T_infor","wb")
pickle.dump(a,f)
# f=open('sch_infor','rb')
# print(pickle.load(f))

# data=pickle.load(f)

