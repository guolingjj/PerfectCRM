from conf import settings
from core import Administrator
from core import all_class
from core import Student_home
from core import teacher_home
import pickle

def opfile(who):
    f=open(settings.BASE_DIR+"\\db\\"+who,"rb")
    data=pickle.load(f)
    f.close()
    return data
def A_login():
    data=opfile("Adinfor")
    account=input("a请输入你的账号")
    psw=input("请输入你的密码")
    if data['account']==account and data['psw']==psw:
        if account=="123":
            print("你好，管理员")
            return Administrator.homeview()
    else:
        print("信息错了")
def s_login():
    # data=opfile("student")
    f = open(settings.BASE_DIR + "\\db\\stu_infor", "rb")
    a = pickle.load(f)
    f.close()
    account=input("b请输入你的账号")
    psw=input("请输入你的密码")
    if account in a:
        f = open(settings.BASE_DIR + "\\db\\"+account, "rb")
        data = pickle.load(f)

        if data.psw==psw:

            return Student_home.S_home(data)
        else:
            print("信息错了")
        f.close()
    else:
        print('未找到账号信息，请注册')
def t_login():
    f = open(settings.BASE_DIR + "\\db\\T_infor", "rb")
    a = pickle.load(f)
    f.close()
    ac = input("b请输入你的账号")
    psw = input("请输入你的密码")
    if ac in a:
        f = open(settings.BASE_DIR + "\\db\\" + ac, "rb")
        data = pickle.load(f)

        if data.psw == psw:

            return teacher_home.T_home()
        else:
            print("信息错了")
        f.close()
    else:
        print('未找到账号信息，请注册')
def register():
    account=input('请输入你的账号')
    name=input('请输入你的姓名')
    psw=input('请输入你的密码')
    age=input('请输入你的年龄')
    s=all_class.Student(name,age,account,psw)
    f = open(settings.BASE_DIR + "\\db\\" + account, "wb")

    pickle.dump(s,f)
    f.close()
    f = open(settings.BASE_DIR + "\\db\\stu_infor", "rb")
    a=pickle.load(f)

    f.close()
    a.append(account)
    print(a)
    f = open(settings.BASE_DIR + "\\db\\stu_infor", "wb")

    pickle.dump(a,f)
    print('创建成功')

    # f = open(settings.BASE_DIR + "\\db\\" + account, "rb")
    # s=pickle.load(f)
    # print(s)


