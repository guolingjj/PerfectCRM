from conf import settings
from core import all_class
import pickle
def homeview():
    obj=loaddate()
    print('''
    welcome
    你可以：
    1：创建课程
    2：创建班级
    3：创建一个老师
    4：创建学校
    5：查看学校所有信息
    

    choice one




    ''')
    op=input('>>>')
    dit={
        '1':C_course,
        '2':C_clazz,
        '3':C_teacher,
        "4":c_School,
        '5':show



    }
    dit[op](obj)

def c_School(obj):
    BJ_s=all_class.School('北京大学','帝都')
    dumpdata(BJ_s)
def C_course(obj):

    name=input("课程名字")
    price=input("课程价钱")
    cycle=input("课程周期")
    obj.c_course(name,price,cycle)
    dumpdata(obj)
    print('创建成功')
def C_clazz(obj):
    name = input("班级名字")

    cteacher=input('班级的老师是？')
    while True:
        ccourse = input("班级的课程是？")
        if ccourse in obj.course:
            ccourse=obj.course[ccourse]
            break
        else:
            print('没有此课程，请重新输入')

    # while True:
    #     cteacher = input('班级的老师是？')
    #     if ccourse in obj.course:
    #         ccourse=obj[ccourse]
    #         break
    #     else:
    #         print('没有此课程，请重新输入')
    obj.c_clazz(name,ccourse,cteacher)
    dumpdata(obj)
    print('创建成功')


def loaddate():
    f = open(settings.BASE_DIR + "\\db\\sch_infor", "rb")
    obj=pickle.load(f)
    f.close()
    return obj
def dumpdata(obj):
    f = open(settings.BASE_DIR + "\\db\\sch_infor", "wb")
    pickle.dump(obj,f)
    f.close()
def C_teacher(obj):
    name = input("老师名字")
    age = input("老师年龄")
    ac=input('登录账号')
    psw=input('登录密码')
    s=all_class.Teacher(name,age,obj.name,ac,psw)
    f = open(settings.BASE_DIR + "\\db\\"+ac, "wb")
    pickle.dump(s,f)
    f.close()
    f = open(settings.BASE_DIR + "\\db\\T_infor", "rb")
    a = pickle.load(f)

    f.close()
    a.append(ac)
    print(a)
    f = open(settings.BASE_DIR + "\\db\\T_infor", "wb")

    pickle.dump(a, f)
    print('创建成功')
def show(obj):
    print(obj.course)

