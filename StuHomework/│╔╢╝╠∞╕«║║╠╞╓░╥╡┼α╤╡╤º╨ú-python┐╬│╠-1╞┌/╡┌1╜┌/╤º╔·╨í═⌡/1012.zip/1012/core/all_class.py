class School:
    def __init__(self,name,province):
        self.name=name
        self.province=province
        self.course={}
        self.clazz={}
    def c_course(self,name,price,cycle):
        self.course[name]=Course(name,price,cycle)
    def c_clazz(self,name,ccourse,cteacher):
        self.clazz[name]=clazz(name,ccourse,cteacher)

class clazz:
    def __init__(self,name,ccourse,cteacher):
        self.name=name
        self.ccourse=ccourse
        self.cteacher=cteacher
        self.c_list=[]
    def addStu(self,Stu):
        self.c_list.append(Stu)


class Course:
    def __init__(self,name,price,cycle):
        self.name=name
        self.price=price
        self.cycle=cycle
    def __str__(self):
        return '%s：价格%d,周期%s'%(self.name,self.price,self.cycle)
class Teacher:
    def __init__(self,name,age,school,ac,psw):
        self.account=ac
        self.psw=psw
        self.T_school=school
        self.name=name
        self.age=age
    def getSlist(self,Tclazz):
        return Tclazz.c_list
    def modiGrade(self,Stu,V):
        Stu.grade=V

class Student:

    def __init__(self,name,age,ac,psw):
        self.account=ac
        self.psw=psw
        self.S_school=None
        self.name=name
        self.age=age
        self.grade=None
        self.clazz=None
    def choice_s(self,school):
        self.S_school=school

    def choice_c(self,clazz):
        self.S_clazz=clazz
# s=Student('123',123)
# print(s.__dict__)

