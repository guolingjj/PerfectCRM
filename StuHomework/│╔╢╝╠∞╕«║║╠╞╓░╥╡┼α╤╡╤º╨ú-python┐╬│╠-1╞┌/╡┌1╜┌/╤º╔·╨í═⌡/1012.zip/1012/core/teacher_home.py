def T_home():
    print('''
    欢迎你，老师
    1：查看你的班级
    2：选择班级上课
    3：查看班级成员
    4：修改学生成绩
    
    
    
    
    ''')
def showclass():
    pass
def upclass():
    pass
def showclass_s():
    pass
def modify():
    pass

