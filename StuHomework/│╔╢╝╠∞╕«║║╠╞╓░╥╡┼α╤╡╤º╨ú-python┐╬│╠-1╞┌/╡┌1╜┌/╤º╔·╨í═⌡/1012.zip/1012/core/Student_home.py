
def S_home(S_obj):
    print('''
       亲爱的同学：
       1：查看成绩
       2：选课
       3: 缴费



       ''')
    op = input(">>>")
    # if op=="1":
    #     showGrade(S_obj)
    # if op==""
    dit={
        "1":showGrade,
        '2':select,
        '3':pay



    }
    dit[op](S_obj)
def showGrade(S_obj):
    print(S_obj.grade)

def select(S_obj):
    pass
def pay(S_obj):
    pass